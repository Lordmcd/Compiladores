/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Unidade2;

import java.io.*;

public class GeraLexer {
    
    public static void main(String[] args) throws IOException{
        
        String CaminhoArquivo = "C:/Users/sherl/OneDrive/Documents/NetBeansProjects/Unidade2/src/Unidade2/especificacao.flex";
        
        File arquivo = new File(CaminhoArquivo);
        
        jflex.Main.generate(arquivo);
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Unidade2;

import java.io.*;

public class TesteAnalisador {
    
    public static void main(String[] args) throws IOException{
        
        String arquivo = "C:/Users/sherl/OneDrive/Documents/NetBeansProjects/Unidade2/src/Unidade2/codigofonte.txt";
    
        BufferedReader texto = new BufferedReader(new FileReader(arquivo));
    
        Lexer analise = new Lexer(texto);
    
        while(true){
            Token objetotoken = analise.yylex();
            if(objetotoken == null)
                break;
        }
    }
}

package unidade2;

public enum teste {
    INDENTIFICADOR,
    CONSTANTE,
    INTEIRO,
    DECIMAL,
    OPERADORARITMETICO,
    OPERADORCOMPARATIVO,
    OPERADORLOGICO,
    SIMBOLOESPECIAL,
    BRANCO,
    PALAVRACHAVE,
    ERROR;




}
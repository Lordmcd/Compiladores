
package aula1;

import java.io.*;

public class GeraLexer {
    
    public static void main(String[] args) throws IOException{
        
        String CaminhoArquivo = "C:/Users/sherl/OneDrive/Documents/NetBeansProjects/aula1/src/aula1/especificacao.flex";
        
        File arquivo = new File(CaminhoArquivo);
        
        jflex.Main.generate(arquivo);
    }
    
}

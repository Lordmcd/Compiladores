
package aula1;


public enum Token {
    NOME_VARIAVEL,
    INT,
    DEC,
    COMENTARIO,
    BRANCO,
    PALAVRA_CHAVE,
    ERROR;
    
}
